﻿using UnityEngine;
using HarmonyLib;


namespace ZenonsModTemplate.Patches.OnGameInitalised
{
    [HarmonyPatch(typeof(GorillaLocomotion.Player), "Awake")]
    public class GameInitPatch
    {
        public static void Postfix() 
        {
            Plugin.instance.OnGameInitialised();
          
            Debug.Log($"k"); 
        }
    }
}
