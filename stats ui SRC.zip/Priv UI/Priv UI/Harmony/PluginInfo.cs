﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ZenonsModTemplate
{
    public class PluginInfo
    {
        public const string GUID = "Divine.StatsUI";
        public const string Name = "Stats UI";
        public const string Version = "1.0.0";
    }
}
