﻿
using ExitGames.Client.Photon;
using GorillaNetworking;
using Photon.Pun;
using Photon.Realtime;
using PlayFab.ClientModels;
using PlayFab;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Unity;
using UnityEngine;
using System.Collections.Specialized;
using System.Net;
using static OVRPlugin;
using ZenonsModTemplate;
using System.Threading;
using System.Text.RegularExpressions;
using System.IO;
using static Photon.Pun.UtilityScripts.TabViewManager;
using Steamworks;
using Unity.Burst.Intrinsics;
using Newtonsoft.Json;
using BepInEx;
namespace Priv_UI
{
    public class Main : MonoBehaviour
    {
        public static Rect sigma = new Rect(500, 15, 500, 700);
        public static string Color = "#46D3FE";
        public static string room;
       
        public void OnGUI()
        {
        if(PhotonNetwork.InRoom)
            {
                room = $"Room Code:{PhotonNetwork.CurrentRoom.Name}";
            }
        else
            {
                room = "";
            }
            GUI.Label(new Rect(10, 10, 250, 500), $"<color={Color}>Stats UI</color>\nFPS:{Mathf.Ceil(1f / Time.unscaledDeltaTime).ToString()}\nName:{PhotonNetwork.LocalPlayer.NickName}\nID:{PhotonNetwork.LocalPlayer.UserId}\n{room}");
         

        }
    }
}




 